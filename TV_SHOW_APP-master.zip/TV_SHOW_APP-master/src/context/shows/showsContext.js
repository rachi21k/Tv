import { createContext } from "react";

const showsContext = createContext();

export default showsContext;
