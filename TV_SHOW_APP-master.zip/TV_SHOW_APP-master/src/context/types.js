// Shows
export const SEARCH_SHOWS = "SEARCH_SHOWS";
export const SET_LOADING = "SET_LOADING";
export const SET_SINGLE_SHOW = "SET_SINGLE_SHOW";
export const CLEAR_SINGLE_SHOW = "CLEAR_SINGLE_SHOW";

// Alerts
export const SET_ALERT = "SET_ALERT";
export const REMOVE_ALERT = "REMOVE_ALERT";
