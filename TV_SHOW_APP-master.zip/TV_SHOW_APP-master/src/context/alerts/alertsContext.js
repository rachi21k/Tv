import { createContext } from "react";

const alertsContext = createContext();

export default alertsContext;
